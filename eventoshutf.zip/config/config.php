<?php

define('HOST', '127.0.0.1');
define('USER', 'root');
define('PASS', 'Caratuma11');
define('BASE', 'eventus');
